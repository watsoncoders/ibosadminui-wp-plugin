
var help_winTitleText		= "";
var help_keywordsText		= "";
var help_descriptionText	= "";
var help_rewriteNameText 	= "";

