<?php 


echo "xmlResponse = <users><user><id>1</id></user></users>";

?> 

