<?

/* --------------------------------------------------------------------------------------------	*/
/* formatBoolean																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatBoolean ($value)
{
	if ($value == "1")
		$value = "��";
	else
		$value = "-";

	return commonPhpEncode ($value);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatBoxType 																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatBoxType ($value)
{
	global $cookie_guiLang;

	$textValue = "";
	
	switch ($value)
	{
		case "links"			: $textValue =  (($cookie_guiLang == "HEB") ? "���� �������" : "Links box");
								  break;
		case "html"				: $textValue =  (($cookie_guiLang == "HEB") ? "���� HTML" : "HTML box");
								  break;
		case "news"				: $textValue =  (($cookie_guiLang == "HEB") ? "���� �����" : "News box");
								  break;
		case "music"			: $textValue =  (($cookie_guiLang == "HEB") ? "���� ������" : "Music box");
								  break;
		case "shopCategories"	: $textValue =  (($cookie_guiLang == "HEB") ? "���� �������� ����/�����" : "");
						  		  break;
		case "forumCategories"	: $textValue =  (($cookie_guiLang == "HEB") ? "���� �������� �������" : "");
						  	 	  break;
		case "galleryCategories": $textValue =  (($cookie_guiLang == "HEB") ? "���� �������� �����" : "");
						  		  break;
		case "pageCategories"	: $textValue =  (($cookie_guiLang == "HEB") ? "���� �������� ����" : "");
						  		  break;
		case "essayCategories"	: $textValue =  (($cookie_guiLang == "HEB") ?  "���� �������� �����" : "");
						  		  break;
		case "cart"				: $textValue =  (($cookie_guiLang == "HEB") ? "���� �����" : "");
						  		  break;
		case "freeCategoris"	: $textValue =  (($cookie_guiLang == "HEB") ? "���� �������� �������" : "");
						  		  break;
		case "innerSearch"		: $textValue =  (($cookie_guiLang == "HEB") ? "���� ����� �����" : "");
						  		  break;
		case "googleSearch"		: $textValue =  (($cookie_guiLang == "HEB") ? "���� ����� ����" : "");
						  		  break;
		case "googleAds"		: $textValue =  (($cookie_guiLang == "HEB") ? "���� ������ ����" : "");
						  		  break;
		case "login"			: $textValue =  (($cookie_guiLang == "HEB") ? "���� User Login" : "");
						  		  break;
	}
	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatBoxPlace 																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatBoxPlace ($value)
{
	global $cookie_guiLang;

	$textValue = "";
	switch ($value)
	{
		case "l"	: $textValue =  (($cookie_guiLang == "HEB") ? "�� ����" : "Left");
					  break;
		case "r"	: $textValue =  (($cookie_guiLang == "HEB") ? "�� ����" : "Right");
					  break;
		case "t"	: $textValue =  (($cookie_guiLang == "HEB") ? "�����" : "Up");
				  	  break;
		case "b"	: $textValue =  (($cookie_guiLang == "HEB") ? "����" : "Down");
				  	  break;
	}
	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatLinkType 																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatLinkType ($value)
{
	global $cookie_guiLang;

	$textValue = "";
	
	switch ($value)
	{
		case "page"				: $textValue =  (($cookie_guiLang == "HEB") ? "����� ���" : "Page link");
					  			  break;
		case "url"				: $textValue =  (($cookie_guiLang == "HEB") ? "����� URL" : "URL link");
					  			  break;
		case "urlNoFollow"		: $textValue =  (($cookie_guiLang == "HEB") ? "����� URL-No-Follow" : "URL No-Follow");
					  			  break;
		case "forum"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� ������" : "Forum link");
					 			  break;
		case "gallery"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� ������" : "Gallery link");
					 			  break;
		case "questionnaire"	: $textValue =  (($cookie_guiLang == "HEB") ? "����� ������" : "Questionnaire link");
					 			  break;
		case "album"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� ������" : "Album link");
					 			  break;
		case "essay"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� �����" : "Essay link");
						 		  break;
		case "nadlan"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� ���� ���\"�" : "Nadlan tablet link");
						 		  break;
		case "file"				: $textValue =  (($cookie_guiLang == "HEB") ? "����� �����" : "File link");
					 	  		  break;
		case "addToFavorite"	: $textValue =  (($cookie_guiLang == "HEB") ? "���� ��������" : "Add to favorites");
							 	  break;
		case "makeHomePage"		: $textValue =  (($cookie_guiLang == "HEB") ? "���� ��� ����" : "Make homepage");
							 	  break;
		case "onclick"			: $textValue =  (($cookie_guiLang == "HEB") ? "����� onclick" : "Onclick link");
							 	  break;
		case "staticName"		: $textValue =  (($cookie_guiLang == "HEB") ? "����� ��� ����� �����" : "Rewrite name link");
							 	  break;
	}
	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatUrlTarget 																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatUrlTarget ($value)
{
	global $cookie_guiLang;

	$textValue = "";
	
	switch ($value)
	{
		case "_blank"	: $textValue =  (($cookie_guiLang == "HEB") ? "��� ���" : "Open in new window");
					  	  break;
		case "_self"	: $textValue =  (($cookie_guiLang == "HEB") ? "����" : "Open in the same window");
					  	  break;
	}
	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatCurrency																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatCurrency ($currency)
{
	global $cookie_guiLang;

	$textValue = "";
	switch ($currency)
	{
		case "ILS"		: $textValue = (($cookie_guiLang == "HEB") ? "�\"�" : "NIS");
						  break;
		case "USD"		: $textValue = (($cookie_guiLang == "HEB") ? "����" : "USD");
						  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatAmount																					*/
/* --------------------------------------------------------------------------------------------	*/
function formatAmount ($amount)
{
	return (sprintf("%01.2f", $amount));
}

/* --------------------------------------------------------------------------------------------	*/
/* formatFileType																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatFileType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "pic"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Picture");
					  break;
		case "video": $textValue = (($cookie_guiLang == "HEB") ? "����� Flash" : "Flash movie");
					  break;
		case "pdf"	: $textValue = (($cookie_guiLang == "HEB") ? "���� PDF" : "PDF");
					  break;
		case "doc"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Doc");
					  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatProductStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatProductStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "0"	: $textValue = (($cookie_guiLang == "HEB") ? "��� !" : "New!");
					  break;
		case "1"	: $textValue = (($cookie_guiLang == "HEB") ? "���� �����" : "Available and shown");
					  break;
		case "2"	: $textValue = (($cookie_guiLang == "HEB") ? "�� ���� �����" : "Not available and shown");
					  break;
		case "3"	: $textValue = (($cookie_guiLang == "HEB") ? "�� ����" : "Not shown");
					  break;
		case "4"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "In sale");
					  break;
		case "5"	: $textValue = (($cookie_guiLang == "HEB") ? "��� �����" : "Stock lacking");
					  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatProductStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatFeaturedProduct ($featured)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($featured)
	{
		case "0"	: $textValue = "-";
					  break;
		case "1"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Choosen");
					  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatCategoryType																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatCategoryType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "global"		: $textValue = (($cookie_guiLang == "HEB") ? "����" : "General");
							  break;
		case "shop"			: $textValue = (($cookie_guiLang == "HEB") ? "���� �� �����" : "Shop/Catalog");
							  break;
		case "forum"		: $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Forums");
							  break;
		case "page"			: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Pages");
					  		  break;
		case "url"			: $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Links");
					  		  break;
		case "essay"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Essays");
					  		  break;
		case "faq"			: $textValue = (($cookie_guiLang == "HEB") ? "��\"�" : "FAQ");
					  		  break;
		case "gallery"		: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Galleries");
					 		  break;
		case "questionnaire": $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Questionnaire");
					 		  break;
		case "album"		: $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Albums");
					 		  break;
		case "banner"		: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Banners");
					 		  break;
		case "survey"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Surveys");
					 		  break;
		case "blog"			: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Blogs");
					 		  break;
		case "blogPost"		: $textValue = (($cookie_guiLang == "HEB") ? "������ ������" : "Blog Posts");
					 		  break;
		case "tabletItem"	: $textValue = (($cookie_guiLang == "HEB") ? "������ ���" : "Tablet messages");
					 		  break;
		case "news"			: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "News");
					 		  break;
		case "phonesBook"	: $textValue = (($cookie_guiLang == "HEB") ? "��� �������" : "Phonebook");
					 		  break;
		case "evnet"		: $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Events");
					 		  break;
		case "member"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ����" : "Member");
					 		  break;
		case "specific"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Specific");
					 		  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatCategoryItemType																		*/
/* --------------------------------------------------------------------------------------------	*/
function formatCategoryItemType ($type, $domainId = 0)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "shop"			: $textValue = (($cookie_guiLang == "HEB") ? "���� �� �����" : "Shop/Catalog");
							  break;
		case "forum"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Forum");
							  break;
		case "page"			: $textValue = (($cookie_guiLang == "HEB") ? "��" : "Page");
					  		  break;
		case "url"			: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Link");
					  		  break;
		case "essay"		: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Essay");
					  		  break;
		case "faq"			: $textValue = (($cookie_guiLang == "HEB") ? "��\"�" : "FAQ");
					  		  break;
		case "gallery"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Gallery");
					 		  break;
		case "questionnaire": $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Questionnaire");
					 		  break;
		case "album"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Album");
					 		  break;
		case "blog"			: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Blog");
					 		  break;
		case "blogPost"		: $textValue = (($cookie_guiLang == "HEB") ? "����� ����" : "Blog Post");
					 		  break;
		case "tabletItem"	: $textValue = (($cookie_guiLang == "HEB") ? "����� ���" : "Tablet message");
					 		  break;
		case "news"			: $textValue = (($cookie_guiLang == "HEB") ? "����" : "News");
					 		  break;
		case "phonesBook"	: $textValue = (($cookie_guiLang == "HEB") ? "��� �������" : "Phonebook");
					 		  break;
		case "event"		: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Event");
					 		  break;
		case "member"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ����" : "Member");
					 		  break;
		case "hug"			: $textValue = (($cookie_guiLang == "HEB") ? "���" : "Hug");
					 		  break;
		case "specific"		: 
			switch ($domainId)
			{
				case "136"	:	// arie
					$textValue = "�����";
					break;

				case "105"	:	// studio123
					$textValue = "�����";
					break;

				case "167"	:	// gs-marketing
					$textValue = "�����";
					break;

				case "191"	:	// inugim
				case "247"	:	// tzoona
				case "268"	: 	// made-in-israel
				case "289"	:	// vradim
				case "409"	:	// wbc plus
					$textValue = "���";
					break;

				case "254"	:	// hasulam
					$textValue = "���� �����";
					break;

				case "369"	:	// isrlist
					$textValue = "������";
					break;

				case "432"	:	// wannado
					$textValue = "������";
					break;

				case "442"	:	// metar
					$textValue = "������";
					break;

				case "523"	:	// koasharot
					$textValue = "�������";
					break;
			}
			break;

		case "specific2"		: 
			switch ($domainId)
			{
				case "254"	:	// hasulam
					$textValue = "����";
					break;

				case "540"	:	// yelonmoreh
					$textValue	= "����";
					break;
			}
			break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatOrderStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatOrderStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "1"	: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Received");
					  break;
		case "2"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Supplied");
					  break;
		case "3"	: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Returned");
					  break;
		case "4"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Canceled");
					  break;
		case "5"	: $textValue = (($cookie_guiLang == "HEB") ? "������ ������" : "Waiting");
					  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatFeedbackStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatFeedbackStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "new"		: $textValue = (($cookie_guiLang == "HEB") ? "����!" : "New!");
					 	  break;
		case "approved"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Confirmed");
						  break;
		case "rejected"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Rejected");
						  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatActiveStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatActiveStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "active"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Active");
					 	  break;
	    case "inactive"	: 
		case "unactive"	: $textValue = (($cookie_guiLang == "HEB") ? "�� ����" : "Inactive");
					      break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatEmailMsgStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatEmailMsgStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "read"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Read");
				 	  break;
		case "new"	: $textValue = (($cookie_guiLang == "HEB") ? "���" : "New");
				      break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatBannerType																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatBannerType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "image"			: $textValue = (($cookie_guiLang == "HEB") ? "�����" : "Picture");
					 		  	  break;
		case "movie"			: $textValue = (($cookie_guiLang == "HEB") ? "����� Flash" : "Flash movie");
					    	  	  break;
		case "htmlCode"			: $textValue = (($cookie_guiLang == "HEB") ? "��� HTML" : "HTML code");
					     	 	  break;
		case "text"				: $textValue = (($cookie_guiLang == "HEB") ? "���� ��������" : "Text Banner");
					     	 	  break;
		case "background"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ���" : "Background Banner");
					      		  break;
		case "backgroundHtml"	: $textValue = (($cookie_guiLang == "HEB") ? "��� HTML" : "HTML Background");
					      		  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatSuperArea																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatSuperArea ($superArea)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($superArea)
	{
		case "north"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "North");
					 	  break;
		case "south"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "South");
						  break;
		case "center"	: $textValue = (($cookie_guiLang == "HEB") ? "����" : "Center");
						  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplTime																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplTime ($time)
{
	if ($time == "" || $time == "00:00:00")
		return "";

	return substr($time, 0, 5);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplDateTime																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplDateTime ($datetime)
{
	if ($datetime == "" || $datetime == "0000-00-00 00:00:00")
		return "";

	$datetime = strtotime($datetime);
	
	$date     = date("d-m-Y", $datetime);
	$time     = date("H:i",   $datetime);
	
//	return ("$date , <font color='gray'>$time</font>");
	return ("$date , $time");
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplDate																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplDate ($datetime)
{
	if ($datetime == "" || $datetime == "0000-00-00" || $datetime == "0000-00-00 00:00:00")
		return "";

	$datetime = strtotime($datetime);
	
	$date     = date("d-m-Y", $datetime);
	
	return ($date);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplShortDate																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplShortDate ($datetime)
{
	if ($datetime == "" || $datetime == "0000-00-00" || $datetime == "0000-00-00 00:00:00")
		return "";

	$datetime = strtotime($datetime);
	
	$date     = date("d-m-y", $datetime);
	
	return ($date);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplFormDateTime																		*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplFormDateTime ($datetime)
{
	if ($datetime == "" || $datetime == "0000-00-00 00:00:00")
		return "";

	$datetime = strtotime($datetime);
	
	$date     = date("d-m-Y", $datetime);
	$time     = date("H:i",   $datetime);
	
	return ("$date $time");
}

/* --------------------------------------------------------------------------------------------	*/
/* formatDayOfWeek																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatDayOfWeek ($date)
{
	global $cookie_guiLang;

	$day	  = date("w", strtotime($date));

	$textValue = "";

	switch ($day)
	{
		case "0"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Sunday");
					  break;
		case "1"	: $textValue = (($cookie_guiLang == "HEB") ? "���" 		: "Monday");
					  break;
		case "2"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Tuesday");
					  break;
		case "3"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Wednesday");
					  break;
		case "4"	: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Thursday");
					  break;
		case "5"	: $textValue = (($cookie_guiLang == "HEB") ? "����" 	: "Friday");
					  break;
		case "6"	: $textValue = (($cookie_guiLang == "HEB") ? "���" 		: "Saturday");
					  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatApplToDB																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatApplToDB ($datetime)
{
	if ($datetime == "") return "";

	$datetime = preg_replace("/^([0-9]{1,2})[\/\. -]+([0-9]{1,2})[\/\. -]+([0-9]{1,4})\s([0-9]{1,2}):([0-9]{2})/", "\\2/\\1/\\3 \\4:\\5", 
						     $datetime);

	$datetime = strtotime($datetime);
	$datetime = date("Y-m-d H:i:00", $datetime);

	return ($datetime);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatTabletType																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatTabletType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "ads"		: $textValue = (($cookie_guiLang == "HEB") ? "������" : "Messages");
					 	  break;
		case "events"	: $textValue = (($cookie_guiLang == "HEB") ? "�������" : "Events");
					      break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatTabletItemStatus																		*/
/* --------------------------------------------------------------------------------------------	*/
function formatTabletItemStatus ($value)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($value)
	{
		case "new"			: $textValue = (($cookie_guiLang == "HEB") ? "����" 	: "New");
							  break;
		case "approved"		: $textValue = (($cookie_guiLang == "HEB") ? "������"	: "Confirmed");
							  break;
		case "rejected"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Rejected");
							  break;
	}

	return $textValue;
}

/* --------------------------------------------------------------------------------------------	*/
/* formatPopType																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatPopType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case "popunderLoad"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ���� ���� ������ ���" : "Pop-under window on page loading");
					 	  		  break;
		case "popunderUnload"	: $textValue = (($cookie_guiLang == "HEB") ? "���� ���� ���� ������ ����" : "Pop-under window on exit page");
					 	  		  break;
		case "popupLoad"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ���� ��� ������ ���" : "Pop-up window on page loading");
					 	  		  break;
		case "popupUnload"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ���� ��� ������ ����" : "Pop-up window on exit page");
					 	  		  break;
		case "popupMsg"			: $textValue = (($cookie_guiLang == "HEB") ? "����� ����� ������ ���" : "Pop-up message on page loading");
					 	  		  break;
		case "popupOnClose"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ���� ������ �����" : "Pop-up message on exit page");
					 	  		  break;
		case "chooseLang"		: $textValue = (($cookie_guiLang == "HEB") ? "����� ����� ������ ���" : "Pop-up message for choose language");
					 	  		  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatNewsType																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatNewsType ($type)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($type)
	{
		case ""					: $textValue = (($cookie_guiLang == "HEB") ? "��� �����" : "No link");
					 	  		  break;
		case "page"				: $textValue = (($cookie_guiLang == "HEB") ? "����� ���" : "Page link");
					 	  		  break;
		case "url"				: $textValue = (($cookie_guiLang == "HEB") ? "URL" : "URL");
					 	  		  break;
		case "file"				: $textValue = (($cookie_guiLang == "HEB") ? "����� �����" : "File link");
					 	  		  break;
		case "forum"			: $textValue = (($cookie_guiLang == "HEB") ? "����� ������" : "Forum link");
					 	  		  break;
		case "gallery"			: $textValue = (($cookie_guiLang == "HEB") ? "����� ������" : "Gallery link");
					 	  		  break;
		case "questionnaire"	: $textValue = (($cookie_guiLang == "HEB") ? "����� ������" : "Questionnaire link");
					 	  		  break;
		case "essay"			: $textValue = (($cookie_guiLang == "HEB") ? "����� �����" : "Essay link");
					 	  		  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatNewsStatus																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatNewsStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "active"			: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Active");
					 	  		  break;
		case "inactive"			: $textValue = (($cookie_guiLang == "HEB") ? "�� �����" : "Inactive");
					 	  		  break;
		case "sticky"			: $textValue = (($cookie_guiLang == "HEB") ? "�����" 	: "Sticky");
					 	  		  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatPhoneRecordStatus																		*/
/* --------------------------------------------------------------------------------------------	*/
function formatPhoneRecordStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "new"			: $textValue = (($cookie_guiLang == "HEB") ? "���"		: "New");
					 	  	  break;
		case "approved"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Confirmed");
					 	  	  break;
		case "rejected"		: $textValue = (($cookie_guiLang == "HEB") ? "����"		: "Rejected");
					 	  	  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatEventStatus																			*/
/* --------------------------------------------------------------------------------------------	*/
function formatEventStatus ($value)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($value)
	{
		case "new"			: $textValue = (($cookie_guiLang == "HEB") ? "���"		: "New");
					 	  	  break;
		case "approved"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Confirmed");
					 	  	  break;
		case "rejected"		: $textValue = (($cookie_guiLang == "HEB") ? "����"		: "Rejected");
					 	  	  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatNadlanItemStatus																		*/
/* --------------------------------------------------------------------------------------------	*/
function formatNadlanItemStatus ($status)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($status)
	{
		case "new"			: $textValue = (($cookie_guiLang == "HEB") ? "����"		: "New");
					 	  	  break;
		case "approved"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Confirmed");
					 	  	  break;
		case "rejected"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Rejected");
					 	  	  break;
		case "deleted"		: $textValue = (($cookie_guiLang == "HEB") ? "�����"	: "Deleted");
					 	  	  break;
	}

	return commonPhpEncode($textValue);
}

/* --------------------------------------------------------------------------------------------	*/
/* formatContinent																				*/
/* --------------------------------------------------------------------------------------------	*/
function formatContinent ($value)
{
	global $cookie_guiLang;

	$textValue = "";

	switch ($value)
	{
		case "europe"			: $textValue = (($cookie_guiLang == "HEB") ? "������"		: "Europe");
					 	  	      break;
		case "asia"				: $textValue = (($cookie_guiLang == "HEB") ? "����"			: "Asia");
					 	  	      break;
		case "africa"			: $textValue = (($cookie_guiLang == "HEB") ? "������"		: "Africa");
					 	  	      break;
		case "northAmerice"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ������"	: "North America");
					 	  	      break;
		case "southAmerica"		: $textValue = (($cookie_guiLang == "HEB") ? "���� ������"	: "South America");
					 	  	      break;
		case "australia"		: $textValue = (($cookie_guiLang == "HEB") ? "��������"		: "Australia ");
					 	  	      break;
		case "antarctica"		: $textValue = (($cookie_guiLang == "HEB") ? "����������"	: "Antarctica");
					 	  	      break;
	}

	return commonPhpEncode($textValue);
}

?>
